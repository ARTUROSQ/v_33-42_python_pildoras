from setuptools import setup

setup(

    name="paquetecalculos",
    version="1.0",
    description="Paquete de redondeo y potencia",
    author="Arturo",
    author_email="lin.arturox@gmail.com",
    url="N/A",
    packages=["Calculos", "Calculos.redondeo_potencia"]
     

)