def potencia(base, exponente):
    print("El resultado de elevar un numero a la potencia es: ", base**exponente)

def redondear(numero):
    print("El resultado de redondear un numero es: ", round(numero))
